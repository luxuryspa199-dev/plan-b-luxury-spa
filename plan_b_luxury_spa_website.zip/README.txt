PLAN B LUXURY SPA website package

Files:
- index.html: responsive one-page website
- DEPLOY_GUIDE.txt: simple publishing steps

Configured:
- Business: PLAN B LUXURY SPA
- Address: A-block, Plot No 67/1, near Shanti Palace, Block B, Mahipalpur Village, Mahipalpur, New Delhi, Delhi 110037
- WhatsApp: +91 99589 33178
- Prices: intentionally hidden

IMPORTANT:
This package is a website draft, not a live/published website. To make it public, upload index.html to a hosting provider and complete any domain/DNS setup. Domain ownership/availability has not been verified.
